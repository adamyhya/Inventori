/**
 * This view is an example list of people.
 */
Ext.define('Inventori.view.main.List', {
    extend: 'Ext.grid.Grid',
    xtype: 'mainlist',

    requires: [
        'Inventori.store.Personnel'

    ],

    title: 'Daftar Barang',

    store: {
        type: 'personnel'
    },

    columns: [
        { text: 'Nama Barang',  dataIndex: 'nama_barang', width: 250, items:[{
        xtype: 'searchtrigger',
        autoSearch: true
    }] },
        { text: 'Kategori', dataIndex: 'nama_kategori', width: 150 },
        { text: 'Jumlah', dataIndex: 'jumlah_barang', width: 150 },
        { text: 'Jumlah', dataIndex: 'nama_satuan', width: 150 }
        
    ],

    items:[
                    {
                        docked: 'bottom',
                        iconCls: 'x-fa fa-trash-o',
                        xtype: 'button',
                        text: 'Hapus',
                        ui: 'action',
                        scope: this,
                        listeners:{
                            tap: 'hapusBarang'
                    }

                    },
                    {
                        docked: 'bottom',
                        iconCls: 'x-fa fa-plus',
                        xtype: 'button',
                        text: 'Tambah',
                        ui: 'action',
                        scope: this,
                        listeners:{
                            tap: 'addBarang'
                    }

                    },
                    {
                        docked: 'bottom',
                        iconCls: 'x-fa fa-search',
                        xtype: 'button',
                        text: 'Cari',
                        ui: 'action',
                        scope: this,
                        listeners:{
                            tap: 'carik'
                    }

                    }
                    
                    
                    ],
       
    listeners: {
        select: 'onItemSelected'
    }
});
