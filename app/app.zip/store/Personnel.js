Ext.define('Inventori.store.Personnel', {
    extend: 'Ext.data.Store',

    alias: 'store.personnel',
    autoLoad: true,
    autoSync: true,
    fields: [
        'nama_barang', 'nama_kategori', 'jumlah_barang', 'nama_satuan'
    ],


    proxy: {
        type: 'jsonp',
        api: {
            read: "http://localhost/inventaris/apibarang.php"
        },
        reader: {
            type: 'json',
            rootProperty: 'items'
        }
    }
});
